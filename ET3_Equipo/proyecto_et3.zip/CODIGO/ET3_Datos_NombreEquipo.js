// Cambiar "NombreEquipo" por el nombre real del equipo
//Tiene una dedicación estimada de 192 horas.(48 horas por persona)

const def_datos_NombreEquipo = [
    {
        "Entrega": "ET3",
        "Nombre del alumno": "Alumno 1",
        "DNI": "12345678A",
        "Horas dedicadas": 48
    },
    {
        "Entrega": "ET3",
        "Nombre del alumno": "Alumno 2",
        "DNI": "12345678B",
        "Horas dedicadas": 48
    },
    {
        "Entrega": "ET3",
        "Nombre del alumno": "Alumno 3",
        "DNI": "12345678C",
        "Horas dedicadas": 48
    },
    {
        "Entrega": "ET3",
        "Nombre del alumno": "Alumno 4",
        "DNI": "12345678D",
        "Horas dedicadas": 48
    }
];