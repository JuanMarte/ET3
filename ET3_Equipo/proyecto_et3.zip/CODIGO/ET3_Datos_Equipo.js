const def_datos_Equipo = [
    {
        entrega: "ET3",
        nombre: "Alumno 1",
        dni: "12345678A",
        horas: 48
    },
    {
        entrega: "ET3",
        nombre: "Alumno 2",
        dni: "12345678B",
        horas: 48
    },
    {
        entrega: "ET3",
        nombre: "Alumno 3",
        dni: "12345678C",
        horas: 48
    },
    {
        entrega: "ET3",
        nombre: "Alumno 4",
        dni: "12345678D",
        horas: 48
    }
];
